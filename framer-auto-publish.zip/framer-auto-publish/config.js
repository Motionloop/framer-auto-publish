module.exports = {
  editorUrl: 'https://framer.com/projects/MotionLoop-Studio--HK5kUK0Zy8dDw1XQeqHw-cHtr6?duplicate=CJSM2AOHxTvMrYkRWEea&node=eTZMN8eWT'
};
